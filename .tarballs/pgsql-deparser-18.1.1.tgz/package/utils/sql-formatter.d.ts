export declare class SqlFormatter {
    private newlineChar;
    private tabChar;
    private prettyMode;
    constructor(newlineChar?: string, tabChar?: string, prettyMode?: boolean);
    format(parts: string[], separator?: string): string;
    indent(text: string, count?: number): string;
    parens(content: string): string;
    newline(): string;
    tab(): string;
    isPretty(): boolean;
}
