export declare class ListUtils {
    static unwrapList(obj: any): any[];
    static formatList(items: any[], separator: string, prefix: string, formatter: (item: any) => string): string;
}
