"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SqlFormatter = void 0;
class SqlFormatter {
    newlineChar;
    tabChar;
    prettyMode;
    constructor(newlineChar = '\n', tabChar = '  ', prettyMode = true) {
        this.newlineChar = newlineChar;
        this.tabChar = tabChar;
        this.prettyMode = prettyMode;
    }
    format(parts, separator = ' ') {
        return parts.filter(part => part !== null && part !== undefined && part !== '').join(separator);
    }
    indent(text, count = 1) {
        if (!this.prettyMode) {
            return text;
        }
        const indentation = this.tabChar.repeat(count);
        return text.split(this.newlineChar).map(line => line.trim() ? indentation + line : line).join(this.newlineChar);
    }
    parens(content) {
        return `(${content})`;
    }
    newline() {
        return this.newlineChar;
    }
    tab() {
        return this.tabChar;
    }
    isPretty() {
        return this.prettyMode;
    }
}
exports.SqlFormatter = SqlFormatter;
