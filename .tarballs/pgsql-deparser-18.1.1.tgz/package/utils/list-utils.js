"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ListUtils = void 0;
class ListUtils {
    static unwrapList(obj) {
        if (obj === undefined || obj === null) {
            return [];
        }
        if (obj.List !== undefined) {
            return obj.List.items || [];
        }
        if (Array.isArray(obj)) {
            return obj;
        }
        return [obj];
    }
    static formatList(items, separator = ', ', prefix = '', formatter) {
        if (!items || items.length === 0) {
            return '';
        }
        return items
            .map(item => `${prefix}${formatter(item)}`)
            .join(separator);
    }
}
exports.ListUtils = ListUtils;
