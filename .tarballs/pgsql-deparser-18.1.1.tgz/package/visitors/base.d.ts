import { Node } from '@pgsql/types';
import { SqlFormatter } from '../utils/sql-formatter';
export interface DeparserContextOptions {
    isStringLiteral?: boolean;
    parentNodeTypes?: string[];
    indentLevel?: number;
    prettyMode?: boolean;
    formatter?: SqlFormatter;
    select?: boolean;
    from?: boolean;
    group?: boolean;
    sort?: boolean;
    insertColumns?: boolean;
    update?: boolean;
    bool?: boolean;
    isColumnConstraint?: boolean;
    isDomainConstraint?: boolean;
    alterColumnOptions?: boolean;
    alterTableOptions?: boolean;
    isEnumValue?: boolean;
    objtype?: string;
    subtype?: string;
    [key: string]: any;
}
export declare class DeparserContext {
    readonly indentLevel: number;
    readonly prettyMode: boolean;
    readonly isStringLiteral?: boolean;
    readonly parentNodeTypes: string[];
    private readonly formatter;
    readonly select?: boolean;
    readonly from?: boolean;
    readonly group?: boolean;
    readonly sort?: boolean;
    readonly insertColumns?: boolean;
    readonly update?: boolean;
    readonly bool?: boolean;
    readonly isColumnConstraint?: boolean;
    readonly isDomainConstraint?: boolean;
    readonly alterColumnOptions?: boolean;
    readonly alterTableOptions?: boolean;
    readonly isEnumValue?: boolean;
    readonly objtype?: string;
    readonly subtype?: string;
    readonly [key: string]: any;
    constructor({ indentLevel, prettyMode, isStringLiteral, parentNodeTypes, formatter, select, from, group, sort, insertColumns, update, bool, isColumnConstraint, isDomainConstraint, alterColumnOptions, alterTableOptions, isEnumValue, objtype, subtype, ...rest }?: DeparserContextOptions);
    spawn(nodeType: string, overrides?: Partial<DeparserContextOptions>): DeparserContext;
    indent(text: string, count?: number): string;
    newline(): string;
    parens(content: string): string;
    format(parts: string[], separator?: string): string;
    isPretty(): boolean;
}
export interface DeparserVisitor {
    visit(node: Node, context?: DeparserContext): string;
}
export declare abstract class BaseVisitor implements DeparserVisitor {
    abstract visit(node: Node, context?: DeparserContext): string;
    protected getNodeType(node: Node): string;
    protected getNodeData(node: Node): any;
    protected formatList(items: any[], separator: string, prefix: string, formatter: (item: any) => string): string;
    protected formatParts(parts: string[], separator?: string): string;
    protected formatParens(content: string): string;
    protected formatIndent(text: string, count?: number): string;
}
