"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseVisitor = exports.DeparserContext = void 0;
const sql_formatter_1 = require("../utils/sql-formatter");
class DeparserContext {
    indentLevel;
    prettyMode;
    isStringLiteral;
    parentNodeTypes;
    formatter;
    select;
    from;
    group;
    sort;
    insertColumns;
    update;
    bool;
    isColumnConstraint;
    isDomainConstraint;
    alterColumnOptions;
    alterTableOptions;
    isEnumValue;
    objtype;
    subtype;
    constructor({ indentLevel = 0, prettyMode = true, isStringLiteral, parentNodeTypes = [], formatter, select, from, group, sort, insertColumns, update, bool, isColumnConstraint, isDomainConstraint, alterColumnOptions, alterTableOptions, isEnumValue, objtype, subtype, ...rest } = {}) {
        this.indentLevel = indentLevel;
        this.prettyMode = prettyMode;
        this.isStringLiteral = isStringLiteral;
        this.parentNodeTypes = parentNodeTypes;
        this.formatter = formatter || new sql_formatter_1.SqlFormatter('\n', '  ', prettyMode);
        this.select = select;
        this.from = from;
        this.group = group;
        this.sort = sort;
        this.insertColumns = insertColumns;
        this.update = update;
        this.bool = bool;
        this.isColumnConstraint = isColumnConstraint;
        this.isDomainConstraint = isDomainConstraint;
        this.alterColumnOptions = alterColumnOptions;
        this.alterTableOptions = alterTableOptions;
        this.isEnumValue = isEnumValue;
        this.objtype = objtype;
        this.subtype = subtype;
        Object.assign(this, rest);
    }
    spawn(nodeType, overrides = {}) {
        return new DeparserContext({
            indentLevel: this.indentLevel,
            prettyMode: this.prettyMode,
            isStringLiteral: this.isStringLiteral,
            parentNodeTypes: [...this.parentNodeTypes, nodeType],
            formatter: this.formatter,
            select: this.select,
            from: this.from,
            group: this.group,
            sort: this.sort,
            insertColumns: this.insertColumns,
            update: this.update,
            bool: this.bool,
            isColumnConstraint: this.isColumnConstraint,
            isDomainConstraint: this.isDomainConstraint,
            alterColumnOptions: this.alterColumnOptions,
            alterTableOptions: this.alterTableOptions,
            isEnumValue: this.isEnumValue,
            objtype: this.objtype,
            subtype: this.subtype,
            ...overrides,
        });
    }
    indent(text, count) {
        if (!this.prettyMode) {
            return text;
        }
        const indentCount = count !== undefined ? count : this.indentLevel + 1;
        return this.formatter.indent(text, indentCount);
    }
    newline() {
        return this.formatter.newline();
    }
    parens(content) {
        return this.formatter.parens(content);
    }
    format(parts, separator) {
        return this.formatter.format(parts, separator);
    }
    isPretty() {
        return this.formatter.isPretty();
    }
}
exports.DeparserContext = DeparserContext;
class BaseVisitor {
    getNodeType(node) {
        return Object.keys(node)[0];
    }
    getNodeData(node) {
        const type = this.getNodeType(node);
        return node[type];
    }
    formatList(items, separator = ', ', prefix = '', formatter) {
        if (!items || items.length === 0) {
            return '';
        }
        return items
            .map(item => `${prefix}${formatter(item)}`)
            .join(separator);
    }
    formatParts(parts, separator = ' ') {
        return parts.filter(part => part !== null && part !== undefined && part !== '').join(separator);
    }
    formatParens(content) {
        return `(${content})`;
    }
    formatIndent(text, count = 1) {
        return text;
    }
}
exports.BaseVisitor = BaseVisitor;
