import { Deparser, DeparserOptions } from "./deparser";
declare const deparseMethod: typeof Deparser.deparse;
export declare const deparseSync: typeof Deparser.deparse;
export declare const deparse: (...args: Parameters<typeof deparseMethod>) => Promise<ReturnType<typeof deparseMethod>>;
export { Deparser, DeparserOptions };
export { QuoteUtils } from '@pgsql/quotes';
