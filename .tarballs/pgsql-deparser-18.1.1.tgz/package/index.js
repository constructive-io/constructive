"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.QuoteUtils = exports.Deparser = exports.deparse = exports.deparseSync = void 0;
const deparser_1 = require("./deparser");
Object.defineProperty(exports, "Deparser", { enumerable: true, get: function () { return deparser_1.Deparser; } });
const deparseMethod = deparser_1.Deparser.deparse;
// Export the original sync version as deparseSync
exports.deparseSync = deparseMethod;
// Create an async wrapper for deparse
const deparse = async (...args) => {
    return deparseMethod(...args);
};
exports.deparse = deparse;
var quotes_1 = require("@pgsql/quotes");
Object.defineProperty(exports, "QuoteUtils", { enumerable: true, get: function () { return quotes_1.QuoteUtils; } });
