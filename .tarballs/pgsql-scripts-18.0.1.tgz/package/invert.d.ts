import { StatementFacts } from '@pgsql/transform';
/** A generated script plus non-fatal notes about what could not be derived. */
export interface GeneratedScript {
    sql: string;
    warnings: string[];
}
type AnyNode = Record<string, any>;
/**
 * Derive the revert script for a classified deploy script: mechanical
 * inverses in reverse topological order of the statement dependency graph.
 *
 * Reverse topo order means every object is dropped before anything it
 * depends on, so drops never need CASCADE. Statements with no derivable
 * inverse contribute a `-- revert not derivable` comment and a warning.
 */
export declare function revertFor(facts: StatementFacts[]): GeneratedScript;
/**
 * Derive the verify script for a classified deploy script: one existence
 * check per created object, in source order (existence checks are order
 * independent; source order keeps output stable). Each check raises a
 * division-by-zero error when the object is missing. Statements whose
 * effect cannot be checked mechanically add a warning and emit nothing.
 */
export declare function verifyFor(facts: StatementFacts[]): GeneratedScript;
/**
 * The inverse of one classified statement as raw AST nodes (each one a
 * wrapped statement node, e.g. `{ DropStmt: {...} }`), or `null` when no
 * inverse is mechanically derivable. An empty array means the statement
 * needs no revert of its own.
 *
 * This is the node-level layer under {@link revertFor}: consumers that
 * compose inverses at the AST level (semantic diffing, migration
 * generation) use this instead of round-tripping through deparsed text.
 * A statement whose inverse is only partially derivable (e.g. an ALTER
 * TABLE where one command cannot be inverted) returns `null` — partial
 * inverses are never silently produced.
 */
export declare function invertStatement(facts: StatementFacts): AnyNode[] | null;
/**
 * The existence checks for one classified statement as raw AST nodes
 * (each one a wrapped `SelectStmt` using the raise-on-failure division
 * idiom), or `null` when no check is mechanically derivable. An empty
 * array means nothing comes into existence (comments, DML, security
 * labels).
 *
 * Node-level layer under {@link verifyFor}. Requires the parser WASM
 * module to be loaded (`loadModule()` from `plpgsql-parser`).
 */
export declare function existenceCheck(facts: StatementFacts): AnyNode[] | null;
export {};
