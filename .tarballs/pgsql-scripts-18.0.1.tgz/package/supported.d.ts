/**
 * The statement vocabulary supported by {@link revertFor} / {@link verifyFor}.
 *
 * Anything outside this list is never guessed at: `revertFor` emits a
 * `-- revert not derivable: <reason>` comment plus a warning, and
 * `verifyFor` emits nothing plus a warning.
 */
/** One supported statement shape and what is generated for it. */
export interface SupportedStatement {
    /** Human-readable statement shape, e.g. `CREATE TABLE`. */
    statement: string;
    /** Parser node tag(s) the shape corresponds to. */
    nodeTags: string[];
    /** What `revertFor` emits, or `null` when there is nothing to revert. */
    revert: string | null;
    /** What `verifyFor` emits, or `null` when there is nothing to verify. */
    verify: string | null;
}
export declare const SUPPORTED_STATEMENTS: readonly SupportedStatement[];
/** Node tags with at least one supported inverse or verify derivation. */
export declare const SUPPORTED_NODE_TAGS: ReadonlySet<string>;
